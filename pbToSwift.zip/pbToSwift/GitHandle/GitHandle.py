import os
from git import Repo
from git.repo.fun import is_git_dir

# 项目路径
static_path = ""
# repo = Repo(sourceDir) #sourceDir是你的项目的路径，不会修改覆盖你的项目，可以放心调用。

class GitHandle(object):
    # repo = Repo()
    # project_path = ""
    # def __init__(self, projectPath, branch='master'):
    #     self.repo = Repo(projectPath)
    #     self.project_path = projectPath
    #     self.initial()

    """
    git仓库管理
    """
    def __init__(self, local_path, repo_url, branch='master'):
        self.local_path = local_path
        self.repo_url = repo_url
        self.repo = None
        self.initial(repo_url, branch)

    """
    初始化git仓库
    param repo_url:
    param branch:
    return:
    """
    def initial(self, repo_url, branch):
        if not os.path.exists(self.local_path):
            os.makedirs(self.local_path)

        git_local_path = os.path.join(self.local_path, '.git')
        if not is_git_dir(git_local_path):
            self.repo = Repo.clone_from(repo_url, to_path=self.local_path, branch=branch)
        else:
            self.repo = Repo(self.local_path)

    def pull(self):
        self.repo.git.pull()

    # def commit(self):
    #     self.repo.git.add('--all')
    #     self.repo.git.commit("-m auto update")

    def push(self):
        self.repo.git.add('--all')
        self.repo.git.commit("-m auto update")
        self.repo.git.push()
        print("推送成功")

    """
    配置tag号， 在最后一位，自增1
    """
    def configCurrentTag(self) -> str:
        tags = self.repo.tags
        last_tag = self.getCurrentTag(tags)
        print("git上最新tag号为：" + str(last_tag))
        tag_split = str(last_tag).split(".")
        tag_commint = ""
        for split in tag_split:
            if split == tag_split[-1]:
                tag_num_add = int(tag_split[-1]) + 1
                tag_commint = tag_commint + str(tag_num_add)
            else:
                tag_commint = tag_commint + split + "."
        print("本次提交tag号为：" + tag_commint)
        return tag_commint

    def getCurrentTag(self, tag_list) -> str:
        max_tag = ""
        for (index, tag) in enumerate(tag_list):
            # print(max_tag)
            if len(max_tag) > 0:
                currents = str(tag).split(".")
                lasts = str(max_tag).split(".")
                for (i, current_split) in enumerate(currents):
                    if int(current_split) > int(lasts[i]):
                        # 目前版本大于一个版本，替换
                        max_tag = tag.name
            else:
                # 初始化赋值
                max_tag = tag.name
        return max_tag

    """
    添加tag 在最后一位，自增1
    """
    def addTag(self):
        tag = self.configCurrentTag()
        self.repo.create_tag(tag)
        self.repo.remote('origin').push(tag)
        print("已更新最新tag号 -> " + tag)

if __name__ == '__main__':
    projectPath = "/Users/stary/Desktop/丶/Project/WehearPBPod"
    repoUrl = "https://gitlab.ihuayue.cn/wehear_ios/WehearPB.git"
    handle = GitHandle(local_path=projectPath, repo_url=repoUrl)
    # handle.pull()
    # handle.push()
    handle.addTag()
