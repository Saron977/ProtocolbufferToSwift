from GitHandle.GitHandle import GitHandle
from PbHandle.PbHandle import PbHandle

if __name__ == '__main__':
    # 需要配置
    '''
    需要修改 - pbToSwift脚本目录前置路径
    '''
    pbToSwiftDirPath = "/Users/stary/Desktop/丶/shell"
    '''
    需要修改 - pbPod 项目目录
    '''
    pb_pod_local_path = "/Users/stary/Desktop/丶/Project/WehearPBPod"
    '''
    需要修改 - pbPod git地址
    '''
    repo_url = "https://gitlab.ihuayue.cn/wehear_ios/WehearPB.git"
    '''
    需要修改 - 存储pb源文件目录
    '''
    pbSourcePath = "/Users/stary/Desktop/丶/Project/api_pb/proto3"

    # 无需变更
    '''
    保留 wehear 需要用到的pb文件夹
    '''
    weHearDirs = ["common", "wehear", "api"]
    '''
    指定目录 - 存放转化后的pb文件 
    '''
    swiftPbPath = "%s/pbToSwift/PbHandle/swift-pb" %pbToSwiftDirPath
    '''
    指定目录 - 执行转为为swiftPb文件的脚本
    '''
    toPbShellPath = "%s/pbToSwift/PbHandle/pbBash.sh" %pbToSwiftDirPath

    handle = PbHandle(swiftPbPath=swiftPbPath, weHearDirs=weHearDirs)
    # pb 转 swift
    handle.clone(pbShellPath=toPbShellPath, swiftPbPath=swiftPbPath, pbSourcePath=pbSourcePath)
    # 过滤pb文件
    handle.filterWehearPbFile()

    # 提交pod
    '''
    指定目录 - 本地 pbPod 项目地址
    '''
    # pb_pod_local_path = "/Users/stary/Desktop/丶/Project/WehearPBPod"
    # repo_url = "https://gitlab.ihuayue.cn/wehear_ios/WehearPB.git"
    podHandle = GitHandle(local_path=pb_pod_local_path, repo_url=repo_url)
    # 拉取最新
    podHandle.pull()

    # 删除pod库下 pb文件
    '''
    指定目录 - pbPod 目录内存放 swiftPb文件的 文件夹目录
    '''
    pb_pod_source_dir = "%s/WehearPB/Classes" %pb_pod_local_path
    handle.deleteDirs(pb_pod_source_dir, weHearDirs)

    # 移动至pod文件下
    target_path = pb_pod_source_dir
    handle.copyTree(swiftPbPath, target_path)

    # 修改podspec文件内version
    '''
    指定目录 - pbPod 目录内存放的 .podspec 文件, 修改 s.version = xxx , 同步tag
    '''
    path_podspec = "%s/WehearPB.podspec" %pb_pod_local_path
    tag = podHandle.configCurrentTag()
    handle.writePodspecFileToChangeVersion(path_podspec, tag)

    # 提交文件
    podHandle.push()
    # 添加标签
    podHandle.addTag()
