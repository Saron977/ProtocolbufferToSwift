import os
import shutil
from GitHandle import GitHandle

class PbHandle(object):
    # wehear 文件夹
    # weHearDirs = ["common", "wehear"]
    # swiftPbPath = "./swift-pb"

    def __init__(self, swiftPbPath, weHearDirs):
        self.swiftPbPath = swiftPbPath
        self.weHearDirs = weHearDirs

    # 拉取最新
    def clone(self, pbShellPath, swiftPbPath, pbSourcePath):
        cmd = pbShellPath + ' ' + swiftPbPath + ' ' + pbSourcePath
        os.system(cmd)

    # 过滤-> 获取 wehear 文件
    def filterWehearPbFile(self):
        fileDirs = os.listdir(self.swiftPbPath)
        print(fileDirs)

        for dirPath in fileDirs:
            if dirPath.startswith("."):
                print("包含文件夹：" + dirPath)
                continue
            elif dirPath in self.weHearDirs:
                print("包含文件夹：" + dirPath)
                continue
            else:
                print("删除文件夹：" + dirPath)
                filePath = self.swiftPbPath + "/" + dirPath
                self.deleteDir(filePath)

    # # 拷贝文件到 ->
    # def copy(self, toPath):
    #     if not os.path.exists(toPath):
    #         os.makedirs(toPath)
    #
    #     if os.path.exists(self.swiftPbPath):
    #         # root 所指的是当前正在遍历的这个文件夹的本身的地址
    #         # dirs 是一个 list，内容是该文件夹中所有的目录的名字(不包括子目录)
    #         # files 同样是 list, 内容是该文件夹中所有的文件(不包括子目录)
    #         for root, dirs, files in os.walk(self.swiftPbPath):
    #             for file in files:
    #                 src_file = os.path.join(root, file)
    #                 shutil.copy(src_file, toPath)
    #                 print(src_file)

    def deleteDir(self, filePath):
        if os.path.exists(filePath):
            shutil.rmtree(filePath)

    # 删除指定目录下所有文件
    def deleteDirs(self, dirPath, dirList):
        for dirs in dirList:
            filePath = dirPath + "/" + dirs
            self.deleteDir(filePath)

    def copyTree(self, source_path, target_path):
        if os.path.isdir(source_path) and os.path.isdir(target_path):
            filelist_src = os.listdir(source_path)
            for file in filelist_src:
                path = os.path.join(os.path.abspath(source_path), file)
                if os.path.isdir(path):
                    path1 = os.path.join(os.path.abspath(target_path), file)
                    if not os.path.exists(path1):
                        os.mkdir(path1)
                    self.copyTree(path, path1)
                else:
                    with open(path, 'rb') as read_stream:
                        contents = read_stream.read()
                        path1 = os.path.join(target_path, file)
                        with open(path1, 'wb') as write_stream:
                            write_stream.write(contents)
            return True

        else:
            return False

    # 修改podspec文件内，version 版本
    def writePodspecFileToChangeVersion(self, path, version):
        line_to_replace = 10  # 需要修改的行号
        my_file = path
        with open(my_file, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        if len(lines) > int(line_to_replace):
            text = "  s.version          = '%s'" %(version)
            lines[line_to_replace] = ('%s\n' %(text))  # new为新参数，记得加换行符\n
        with open(my_file, 'w', encoding='utf-8') as file:
            file.writelines(lines)


if __name__ == '__main__':
    weHearDirs = ["common", "wehear"]
    swiftPbPath = "/Users/stary/Desktop/丶/shell/pbToSwift/PbHandle/swift-pb"
    handle = PbHandle(swiftPbPath=swiftPbPath, weHearDirs=weHearDirs)
    # pb 转 swift
    pbToSwiftDirPath = "/Users/stary/Desktop/丶/shell"

    swiftPbPath = "%s/pbToSwift/PbHandle/swift-pb" % pbToSwiftDirPath
    toPbShellPath = "%s/pbToSwift/PbHandle/pbBash.sh" % pbToSwiftDirPath
    pbSourcePath = "/Users/stary/Desktop/丶/Project/api_pb/proto3"

    handle.clone(pbShellPath=toPbShellPath, swiftPbPath=swiftPbPath, pbSourcePath=pbSourcePath)
    # # 过滤pb文件
    # handle.filterWehearPbFile()
    #
    # # 提交pod
    # pb_pod_local_path = "/Users/stary/Desktop/丶/Project/WehearPBPod"
    # repo_url = "https://gitlab.ihuayue.cn/wehear_ios/WehearPB.git"
    # podHandle = GitHandle.GitHandle(local_path=pb_pod_local_path, repo_url=repo_url)
    # # 拉取最新
    # podHandle.pull()

    # # 删除pod库下 pb文件
    # pb_pod_source_dir = "/Users/stary/Desktop/丶/Project/WehearPBPod/WehearPB/Classes"
    # weHearDirs = ["common", "wehear"]
    # handle.deleteDirs(pb_pod_source_dir, weHearDirs)
    #
    # # 移动至pod文件下
    # path = "/Users/stary/Desktop/丶/Project/WehearPBPod/WehearPB/Classes"
    # source_path = "./swift-pb"
    # target_path = pb_pod_source_dir
    # handle.copyTree(source_path, target_path)

    # # 修改podspec文件
    # path_podspec = "/Users/stary/Desktop/丶/Project/WehearPBPod/WehearPB.podspec"
    # tag = podHandle.configCurrentTag()
    # handle.writePodspecFileToChangeVersion(path_podspec, tag)

    # # 提交文件
    # podHandle.push()
    # # 添加标签
    # podHandle.addTag()

