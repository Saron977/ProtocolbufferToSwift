#!/bin/bash

# 进入pb转换目录，清空文件
# cd /Users/stary/Desktop/丶/shell/pbToSwift/PbHandle/swift-pb
# 存储转化后pb文件目录
swiftPbPath=$1
# /Users/stary/Desktop/丶/Project/api_pb/proto3
# 存储pb源文件路径
pbSourcePath=$2

if [ ! -d $swiftPbPath ]; then
  eval "没找到指定存储转化后的pb文件目录 -> $swiftPbPath"
  exit 1
fi

if [ ! -d $pbSourcePath ]; then
  eval "没找到指定存pb源文件目录 -> $pbSourcePath"
  exit 1
fi

cd $swiftPbPath
find . -type f -delete

## 进入pb源文件目录
##cd /Users/stary/Desktop/丶/Project/api_pb/proto3
cd $pbSourcePath
printf '********** pb 拉取最新 ***********'
git pull origin master

printf '********** pb 转换开始 ***********'
for file in $(find ./ -type f -name "*.proto");do
  # swift_out: 输出路径
	protoc $file --swift_out=$swiftPbPath --swift_opt=Visibility=Public;
done;
printf '********** pb 转换完成 ***********'
## 打开输出后的文件夹
#open /Users/stary/Desktop/丶/shell/pbToSwift/PbHandle/swift-pb