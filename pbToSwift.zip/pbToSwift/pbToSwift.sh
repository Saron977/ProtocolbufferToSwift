func weHearPbToSwift() {
	python3 /Users/stary/Desktop/丶/shell/pbToSwift/PbToSwiftHandle.py
#	print '********** pb 拉取最新 ***********'
#	git pull origin master
#
#	print '********** pb 转换开始 ***********'
#	for file in $(find ./ -type f -name "*.proto");do
##		protoc $file --swift_out=/Users/stary/Desktop/丶/swift-protobuf;
#    protoc $file --swift_out=/Users/stary/Desktop/丶/shell/pbToSwift/PbHandle/swift-pb --swift_opt=Visibility=Public;
#	done;
#	print '********** pb 转换完成 ***********'
#	open /Users/stary/Desktop/丶/swift-protobuf
}